package qiannian.login.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;
import qiannian.login.utils.JwtUtils;
import qiannian.login.utils.Resultv;
import qiannian.login.entity.Users;
import qiannian.login.mapper.UsersMapper;
import qiannian.login.service.LoginService;

import java.util.concurrent.TimeUnit;

@Service
public class LoginServiceImpl implements LoginService {
    @Autowired
    private UsersMapper usersMapper;
    @Autowired
    private RedisTemplate<String,String> redisTemplate;
    @Override
    public Resultv login(String phone, String password){
        Users users = usersMapper.login(phone);
        if(phone.length()!=11){
            return new Resultv(400,"请输入正确的11位手机号",null);
        } else{
            if (users==null){
                return new Resultv(404,"该手机号未完成注册，请先注册 ",null);
            }
            else if (users.getPassword().equals(password)){
                Users users1 = new Users();
                String token = String.valueOf(JwtUtils.createToken(phone));
                redisTemplate.opsForValue().set("TOKEN_"+token, String.valueOf(users),1, TimeUnit.DAYS);
                return new Resultv(200,"登陆成功",token);
            }else{
                //密码错误
                return new Resultv(401,"密码不正确，请重新输入",null);
            }
        }
    }


}
