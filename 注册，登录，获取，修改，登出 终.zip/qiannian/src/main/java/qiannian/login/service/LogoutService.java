package qiannian.login.service;

import qiannian.login.utils.Resultv;

public interface LogoutService {

     Resultv logout(String token);
}
