package qiannian.login.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import qiannian.login.entity.Users;
import qiannian.login.mapper.UsersMapper;
import qiannian.login.service.RegisterService;
import qiannian.login.utils.JwtUtils;
import qiannian.login.utils.Resultv;

import java.util.UUID;

@Service
public class RegisterServiceImpl implements RegisterService {

    @Autowired
    private UsersMapper usersMapper;

    // 随机头像生成
    private String generateRandomAvatar() {
        String randomStr = UUID.randomUUID().toString().substring(0, 8);
        return "https://picsum.photos/200/200?random=" + randomStr;
    }
    @Override
    public Resultv register(String phone,String password,String confirmPassword,String name){

        if (phone.length() != 11) {
            return new Resultv(400, "请输入正确的11位手机号", null);
        }
        // 确认密码
        if (!password.equals(confirmPassword)) {
            return new Resultv(400, "您两次输入的密码不一致", null);
        }
        // 是否已注册
        Users existUser = usersMapper.login(phone);
        if (existUser != null) {
            return new Resultv(409, "该手机号已注册，请直接登录", null);
        }

        Users users = new Users();
        users.setPhone(phone);
        users.setPassword(password);
        users.setName(name);
        users.setAvatar(generateRandomAvatar());
        // 调用 Mapper 插入数据
        int result = usersMapper.register(users);
        if (result > 0) {
            // 注册成功
            String token = JwtUtils.createToken(phone);
            return new Resultv(200, "注册成功！正在为您登录...", token);
        } else {
            return new Resultv(500, "系统忙，稍等会儿再试试", null);
        }
    }
}

