package qiannian.login.service;

import qiannian.login.utils.Resultv;

public interface RegisterService{
    Resultv register (String phone,String password,String confirmPassword,String name);
}
