package qiannian.login.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import qiannian.login.entity.Users;
import qiannian.login.mapper.UsersMapper;
import qiannian.login.service.UpdateUserInforService;
import qiannian.login.utils.Resultv;

@Service
public class UpdateUserInfoServiceImpl implements UpdateUserInforService {
    @Autowired
    private UsersMapper usersMapper;

    @Override
    public Resultv updateUserInfo(Users user) {
        // 执行更新
        int result = usersMapper.updateUserInfo(user);
        if (result > 0) {
            return new Resultv(200, "信息修改成功", user);
        } else {
            return new Resultv(500, "信息修改失败，请重试", null);
        }
    }

    @Override
    public Resultv updatePhone(String oldphone, String newphone) {
        // 校验新手机号格式
        if (newphone == null || newphone.length() != 11) {
            return new Resultv(400, "请输入正确的11位手机号", null);
        }
        // 校验新手机号是否已被注册
        int count = usersMapper.checkPhoneExists(newphone);
        if (count > 0) {
            return new Resultv(409, "新手机号已被注册", null);
        }
        // 执行手机号更新
        int result = usersMapper.updatePhone(oldphone, newphone);
        if (result > 0) {
            return new Resultv(200, "手机号修改成功", newphone);
        } else {
            return new Resultv(500, "手机号修改失败，请重试", null);
        }
    }
}



