package qiannian.login.service;

import qiannian.login.entity.Users;
import qiannian.login.utils.Resultv;

public interface UpdateUserInforService {

    Resultv updateUserInfo(Users user);

    // 修改手机号（需验证）
    Resultv updatePhone(String oldphone, String newphone);
}
