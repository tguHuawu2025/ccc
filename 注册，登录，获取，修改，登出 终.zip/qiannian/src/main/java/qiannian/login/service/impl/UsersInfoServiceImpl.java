package qiannian.login.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import qiannian.login.entity.Users;
import qiannian.login.mapper.UsersMapper;
import qiannian.login.service.UsersInfoService;
import qiannian.login.utils.JwtUtils;
import qiannian.login.utils.Resultv;

import java.util.Map;

@Service
public class UsersInfoServiceImpl implements UsersInfoService {
    @Autowired
    private UsersMapper usersMapper;

    @Override
    public Resultv getUserInfo(String phone){

        if (phone == null || phone.length() != 11) {
            return new Resultv(400, "请输入正确的11位手机号", null);
        }

        Users user = usersMapper.login(phone);
        if (user == null) {
            return new Resultv(404, "用户不存在", null);
        }
        return new Resultv(200, "获取用户信息成功", user);
    }

    //JWT 解析 token 获取手机号
    @Override
    public Resultv getCurrentUserInfo(String token) {
        Map<String, Object> claims = JwtUtils.checkToken(token);
        if (claims == null) {
            return new Resultv(400, "请提供有效的令牌", null);
        }
        String phone = (String) claims.get("phone");
        return getUserInfo(phone);
    }
}
