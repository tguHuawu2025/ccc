package qiannian.login.mapper;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Component;
import qiannian.login.entity.Users;
@Mapper
public interface UsersMapper {

    //登录接口
     Users login(String phone);

    //注册
    int register(Users users);

    //修改昵称等
    int updateUserInfo(Users users);

    // 新手机号是否已被注册
    int checkPhoneExists(String newphone);

    // 修改手机号
    int updatePhone(@Param("oldphone") String oldphone, @Param("newphone")String newphone);
}
