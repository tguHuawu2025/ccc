package qiannian.login.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import qiannian.login.service.UsersInfoService;
import qiannian.login.utils.Resultv;

@RestController
@RequestMapping(value = "user")
public class UsersInfoController {

    @Autowired
    private UsersInfoService usersInfoService;

    @GetMapping("info")
    public Resultv getCurrentUserInfo(@RequestHeader("Authorization") String authorizationHeader) {
        if (authorizationHeader == null || !authorizationHeader.startsWith("Bearer ")) {
            return new Resultv(400, "请提供有效的令牌", null);
        }
        String token = authorizationHeader.substring(7);
        return usersInfoService.getCurrentUserInfo(token);
    }


}
