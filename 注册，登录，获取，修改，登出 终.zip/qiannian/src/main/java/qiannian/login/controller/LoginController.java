package qiannian.login.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import qiannian.login.entity.Users;
import qiannian.login.utils.Resultv;
import qiannian.login.service.LoginService;

@RestController
@RequestMapping("user")

public class LoginController {

    @Autowired
    private LoginService loginService;

    @PostMapping("login")

    public Resultv login(@RequestBody Users users){
        String phone = users.getPhone();
        String password = users.getPassword();
        //调用业务层
        return loginService.login(phone, password);
    }
}
