package qiannian.login.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import qiannian.login.entity.Users;
import qiannian.login.service.UpdateUserInforService;
import qiannian.login.utils.JwtUtils;
import qiannian.login.utils.Resultv;

import java.util.Map;

@RestController
@RequestMapping("user")
public class UpdateUerInfoController {

    @Autowired
    private UpdateUserInforService updateUserInforService;

    // 修改基本信息（昵称、头像、性别、生日、地址）
    @PostMapping("updateuserinfo")
    public Resultv updateUserInfo(
            @RequestHeader("Authorization") String authorizationHeader,
            @RequestBody Users user) {

        // 校验token
        if (authorizationHeader == null || !authorizationHeader.startsWith("Bearer ")) {
            return new Resultv(400, "请提供有效的令牌", null);
        }
        String token = authorizationHeader.substring(7);
        Map<String, Object> claims = JwtUtils.checkToken(token);
        if (claims == null) {
            return new Resultv(400, "请提供有效的令牌", null);
        }

        // 从token中获取原手机号
        String oldphone = (String) claims.get("phone");
        user.setPhone(oldphone);

        return updateUserInforService.updateUserInfo(user);
    }

    // 修改手机号
    @PostMapping("updatephone")
    public Resultv updatePhone(
            @RequestHeader("Authorization") String authorizationHeader,
            @RequestParam (required = false) String newphone) {

        // 校验token
        if (authorizationHeader == null || !authorizationHeader.startsWith("Bearer ")) {
            return new Resultv(400, "请提供有效的令牌", null);
        }
        String token = authorizationHeader.substring(7);
        Map<String, Object> claims = JwtUtils.checkToken(token);
        if (claims == null) {
            return new Resultv(400, "请提供有效的令牌", null);
        }

        String oldphone = (String) claims.get("phone");
        return updateUserInforService.updatePhone(oldphone, newphone);
    }

}
