package qiannian.login.service;

import qiannian.login.utils.Resultv;

public interface LoginService {
    Resultv login(String phone, String password);
}
