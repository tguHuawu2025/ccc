package qiannian.login.service;

import qiannian.login.utils.Resultv;

public interface UsersInfoService{
    Resultv getUserInfo(String phone);//手机号是查询标识

    Resultv getCurrentUserInfo(String token);//通过token获取手机号

}
