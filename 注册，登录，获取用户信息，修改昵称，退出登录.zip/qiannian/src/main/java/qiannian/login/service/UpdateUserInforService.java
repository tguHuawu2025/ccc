package qiannian.login.service;

import qiannian.login.utils.Resultv;

public interface UpdateUserInforService {
    Resultv updateUserInfo(String phone, String newNickname);
}
