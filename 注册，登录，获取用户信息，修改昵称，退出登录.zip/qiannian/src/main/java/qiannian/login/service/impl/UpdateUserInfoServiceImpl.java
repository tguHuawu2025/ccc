package qiannian.login.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import qiannian.login.entity.Users;
import qiannian.login.mapper.UsersMapper;
import qiannian.login.service.UpdateUserInforService;
import qiannian.login.utils.Resultv;

@Service
public class UpdateUserInfoServiceImpl implements UpdateUserInforService {
    @Autowired
    private UsersMapper usersMapper;

    @Override
    public Resultv updateUserInfo(String phone,String newname){

        if (newname == null || newname.trim().isEmpty()) {
            return new Resultv(400, "昵称不能为空", null);
        }
        // 检查用户是否存在
        Users user = usersMapper.login(phone);
        if (user == null) {
            return new Resultv(404, "用户不存在", null);
        }

        // 更新昵称 头像
        Users updateUser = new Users();
        updateUser.setPhone(phone);
        updateUser.setName(newname);
        int result = usersMapper.updateUserInfo(updateUser);

        if (result > 0) {
            return new Resultv(200, "昵称修改成功", newname);
        } else {
            return new Resultv(500, "昵称修改失败，请重试", null);
        }
    }
}



