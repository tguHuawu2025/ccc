package qiannian.login.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import qiannian.login.service.UpdateUserInforService;
import qiannian.login.utils.JwtUtils;
import qiannian.login.utils.Resultv;

import java.util.Map;

@RestController
@RequestMapping("user")
public class UpdateUerInfoController {

    @Autowired
    private UpdateUserInforService updateUserInforService;

    @PostMapping("updateuserinfo")
    public Resultv updateNickname(
            @RequestHeader("Authorization") String authorizationHeader,
            @RequestParam String newname) {

        if (authorizationHeader == null || !authorizationHeader.startsWith("Bearer ")) {
            return new Resultv(400, "请提供有效的令牌", null);
        }
        String token = authorizationHeader.substring(7);
        Map<String, Object> claims = JwtUtils.checkToken(token);
        if (claims == null) {
            return new Resultv(401, "token无效", null);
        }
        String phone = (String) claims.get("phone");

        return updateUserInforService.updateUserInfo(phone, newname);
    }
}
