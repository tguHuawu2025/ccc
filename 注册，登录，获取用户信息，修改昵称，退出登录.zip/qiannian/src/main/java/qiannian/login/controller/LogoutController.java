package qiannian.login.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import qiannian.login.service.LogoutService;
import qiannian.login.utils.Resultv;

@RestController
@RequestMapping( "user")
public class LogoutController {

    @Autowired
    private LogoutService logoutService;

    @PostMapping("logout")

    public Resultv logout(@RequestHeader("Authorization") String authorizationHeader){
        if (authorizationHeader == null || !authorizationHeader.startsWith("Bearer ")) {
            return new Resultv(400, "请提供有效的令牌", null);
        }
        String token = authorizationHeader.substring(7);//去掉bearer前缀
        return logoutService.logout(token);
    }

}
