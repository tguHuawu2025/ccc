package qiannian.login.utils;

import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.concurrent.TimeUnit;

@Component
public class RedisUtils {
    @Resource
    private RedisTemplate<String,Object> redisTemplate;

    //缓存 无时间限制
    public void set(String key,Object value){
        redisTemplate.opsForValue().set(key, value);
    }

    //缓存 有时间限制
    public void set(String key,Object value,long timeout) {
        redisTemplate.opsForValue().set(key, value, timeout,TimeUnit.SECONDS);
    }

    //删除缓存
    public boolean delete(String key){
        redisTemplate.delete(key);
        //如果还存在这个key就证明删除失败
        if (redisTemplate.hasKey(key)){
            return false;
            //不存在就证明删除成功
        }else {
            return true;
        }
    }

    //取出缓存
    public Object get(String key){
        if (redisTemplate.hasKey(key)){
            return redisTemplate.opsForValue().get(key);
        }else {
            return null;
        }
    }

    //获取失效时间（-2：失效 / -1：没有时间限制
    public long getExpire(String key){
        //判断是否存在
        if (redisTemplate.hasKey(key)){
            return redisTemplate.getExpire(key);
        }else {
            return Long.parseLong(-2 + "");
        }
    }

}
