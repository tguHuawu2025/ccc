package qiannian.login.mapper;

import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Component;
import qiannian.login.entity.Users;
@Mapper
public interface UsersMapper {

    //登录接口
     Users login(String phone);

    //注册
    int register(Users users);

    //修改昵称
    int updateUserInfo(Users users);
}
