package qiannian.login.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import qiannian.login.entity.Users;
import qiannian.login.service.RegisterService;
import qiannian.login.utils.Resultv;

import javax.annotation.Resource;

@RestController
@RequestMapping("user")
public class RegisterController {

    @Autowired
    private RegisterService registerService;

    @PostMapping("register")

    public Resultv register(@RequestBody Users users){
        String phone = users.getPhone();
        String password = users.getPassword();
        String confirmPassword = users.getConfirmPassword();
        String name = users.getName();


        //调用业务层

        return registerService.register(phone, password, name,confirmPassword);
    }

}
