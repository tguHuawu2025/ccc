package qiannian.login.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;
import qiannian.login.service.LogoutService;
import qiannian.login.utils.Resultv;


@Service
public class LogoutServiceImpl implements LogoutService{
    @Autowired
    private RedisTemplate<String,String> redisTemplate;
    @Override
    public Resultv logout(String token){

        String tokenKey = "TOKEN_" + token;

        // 检查令牌是否存在于Redis中
        Boolean hasToken = redisTemplate.hasKey(tokenKey);
        if (hasToken == null || !hasToken) {
            // 令牌不存在或已失效
            return new Resultv(401, "令牌无效或已过期，请勿重复退出", null);
        }

        // 令牌存在
        Boolean deleteResult = redisTemplate.delete(tokenKey);
            redisTemplate.delete("TOKEN_"+token);
            return new Resultv(200, "退出登录成功", null);

    }
}
