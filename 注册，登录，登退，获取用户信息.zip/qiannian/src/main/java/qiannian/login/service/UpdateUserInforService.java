package qiannian.login.service;

import qiannian.login.utils.Resultv;

public interface UpdateUserInforService {
    Resultv updatename(String phone, String newNickname);
}
